package co.edu.unal.tictactoe1;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import edu.harding.tictactoe1.TicTacToeGame;

public class TicTacToeActivity extends AppCompatActivity {

    static final int DIALOG_DIFFICULTY_ID = 0;
    static final int DIALOG_QUIT_ID = 1;
    static final int DIALOG_ABOUT_ID = 2;

    private TicTacToeGame mGame;
    private Button mBoardButtons[];
    private TextView mInfoTextView, mHumanCntTextView, mAndroidCntTextView, mTiesCntTextView;
    private boolean mGameOVer;
    private boolean mFirstHuman;
    private int mCntHumanWins;
    private int mCntTies;
    private int mCntAndroidWins;

    private void startGame(){
        mGame.clearBoard();
        mGameOVer = false;
        for( int i = 0; i < mBoardButtons.length; ++i ){
            mBoardButtons[ i ].setText( "" );
            mBoardButtons[ i ].setEnabled( true );
            mBoardButtons[ i ].setOnClickListener( new ButtonClickListener( i ) );
        }
        updateWinsCnt();
        if( mFirstHuman ) {
            mInfoTextView.setText(R.string.first_human);
        }
        else{
            mInfoTextView.setText(R.string.turn_computer);
            int move = mGame.getComputerMove( );
            setMove( TicTacToeGame.COMPUTER_PLAYER, move );
            mInfoTextView.setText(R.string.turn_human);
        }
    }

    private void setMove( char player, int location ){
        mGame.setMove( player, location );
        mBoardButtons[ location ].setText( String.valueOf( player ) );
        mBoardButtons[ location ].setEnabled( false );
        if( player == TicTacToeGame.HUMAN_PLAYER )
            mBoardButtons[ location ].setTextColor( Color.GREEN );
        else
            mBoardButtons[ location ].setTextColor( Color.RED );
    }

    private void updateWinsCnt(){
        mHumanCntTextView.setText( "Human: " + mCntHumanWins );
        mTiesCntTextView.setText( "Ties: " + mCntTies );
        mAndroidCntTextView.setText( "Android: " + mCntAndroidWins );
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tic_tac_toe);

        mBoardButtons = new Button[TicTacToeGame.BOARD_SIZE];
        mBoardButtons[0] = (Button) findViewById(R.id.bt_one);
        mBoardButtons[1] = (Button) findViewById(R.id.bt_two);
        mBoardButtons[2] = (Button) findViewById(R.id.bt_three);
        mBoardButtons[3] = (Button) findViewById(R.id.bt_four);
        mBoardButtons[4] = (Button) findViewById(R.id.bt_five);
        mBoardButtons[5] = (Button) findViewById(R.id.bt_six);
        mBoardButtons[6] = (Button) findViewById(R.id.bt_seven);
        mBoardButtons[7] = (Button) findViewById(R.id.bt_eight);
        mBoardButtons[8] = (Button) findViewById(R.id.bt_nine);

        mInfoTextView = (TextView) findViewById(R.id.tv_information);
        mHumanCntTextView = (TextView) findViewById(R.id.tv_human_wins);
        mAndroidCntTextView = (TextView) findViewById(R.id.tv_computer_wins);
        mTiesCntTextView = (TextView) findViewById(R.id.tv_ties);
        mGame = new TicTacToeGame();
        mFirstHuman = true;
        mCntHumanWins = mCntTies = mCntAndroidWins = 0;
        startGame();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate( R.menu.options_menu, menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch( item.getItemId() ){
            case R.id.new_game:
                startGame();
                return true;
            case R.id.ai_difficulty:
                showDialog( DIALOG_DIFFICULTY_ID );
                return true;
            case R.id.quit:
                showDialog( DIALOG_QUIT_ID );
                return true;
            case R.id.about:
                showDialog( DIALOG_ABOUT_ID );
                return true;
        }
        return false;
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        switch (id) {
            case DIALOG_DIFFICULTY_ID:

                builder.setTitle(R.string.difficulty_choose);

                final CharSequence[] levels = {
                        getResources().getString(R.string.difficulty_easy),
                        getResources().getString(R.string.difficulty_harder),
                        getResources().getString(R.string.difficulty_expert)};

                // TODO: Set selected, an integer (0 to n-1), for the Difficulty dialog.
                // selected is the radio button that should be selected.
                int selected;
                if( mGame.getDifficultyLevel() == TicTacToeGame.DifficultyLevel.Easy ) selected = 0;
                else if( mGame.getDifficultyLevel() == TicTacToeGame.DifficultyLevel.Harder ) selected = 1;
                else selected = 2;

                builder.setSingleChoiceItems(levels, selected,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int item) {
                                dialog.dismiss();   // Close dialog

                                // TODO: Set the diff level of mGame based on which item was selected.
                                TicTacToeGame.DifficultyLevel difficultyLevel;
                                if( item == 0 ) difficultyLevel = TicTacToeGame.DifficultyLevel.Easy;
                                else if( item == 1 ) difficultyLevel = TicTacToeGame.DifficultyLevel.Harder;
                                else difficultyLevel = TicTacToeGame.DifficultyLevel.Expert;
                                mGame.setDifficultyLevel( difficultyLevel );

                                // Display the selected difficulty level
                                Toast.makeText(getApplicationContext(), levels[item],
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                dialog = builder.create();
                break;

            case DIALOG_QUIT_ID:
                // Create the quit confirmation dialog
                builder.setMessage(R.string.quit_question)
                        .setCancelable(false)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                TicTacToeActivity.this.finish();
                            }
                        })
                        .setNegativeButton(R.string.no, null);
                dialog = builder.create();

                break;

            case DIALOG_ABOUT_ID:
                Context context = getApplicationContext();
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
                View layout = inflater.inflate(R.layout.about_dialog, null);
                builder.setView(layout);
                builder.setPositiveButton("OK", null);
                dialog = builder.create();
                break;
        }
        return dialog;
    }

    private class ButtonClickListener implements View.OnClickListener{
        int location;

        public ButtonClickListener( int location ){
            this.location = location;
        }

        @Override
        public void onClick(View view) {
            if( !mBoardButtons[ location ].isEnabled() || mGameOVer ) return;
            setMove( TicTacToeGame.HUMAN_PLAYER, location );

            int winner = mGame.checkForWinner();
            if( winner == 0 ){
                mInfoTextView.setText( R.string.turn_computer );
                int move = mGame.getComputerMove(  );
                setMove( TicTacToeGame.COMPUTER_PLAYER, move );
                winner = mGame.checkForWinner();
            }
            if( winner == 0 ) mInfoTextView.setText( R.string.turn_human );
            else {
                mGameOVer = true;
                if (winner == 1){
                    ++mCntTies;
                    mInfoTextView.setText( R.string.result_tie );
                }
                else if (winner == 2){
                    ++mCntHumanWins;
                    mInfoTextView.setText( R.string.result_human_wins );
                }
                else{
                    ++mCntAndroidWins;
                    mInfoTextView.setText( R.string.result_computer_wins );
                }
                updateWinsCnt();
                mFirstHuman = !mFirstHuman;
            }
        }
    }

}
