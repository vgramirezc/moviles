package co.edu.unal.tictactoe1;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import edu.harding.tictactoe1.TicTacToeGame;

public class TicTacToeActivity extends AppCompatActivity {

    private TicTacToeGame mGame;
    private Button mBoardButtons[];
    private TextView mInfoTextView, mHumanCntTextView, mAndroidCntTextView, mTiesCntTextView;
    private boolean mGameOVer;
    private boolean mFirstHuman;
    private int mCntHumanWins;
    private int mCntTies;
    private int mCntAndroidWins;

    private void startGame(){
        mGame.clearBoard();
        mGameOVer = false;
        for( int i = 0; i < mBoardButtons.length; ++i ){
            mBoardButtons[ i ].setText( "" );
            mBoardButtons[ i ].setEnabled( true );
            mBoardButtons[ i ].setOnClickListener( new ButtonClickListener( i ) );
        }
        updateWinsCnt();
        if( mFirstHuman ) {
            mInfoTextView.setText(R.string.first_human);
        }
        else{
            mInfoTextView.setText(R.string.turn_computer);
            int move = mGame.getComputerMove();
            setMove( TicTacToeGame.COMPUTER_PLAYER, move );
            mInfoTextView.setText(R.string.turn_human);
        }
    }

    private void setMove( char player, int location ){
        mGame.setMove( player, location );
        mBoardButtons[ location ].setText( String.valueOf( player ) );
        mBoardButtons[ location ].setEnabled( false );
        if( player == TicTacToeGame.HUMAN_PLAYER )
            mBoardButtons[ location ].setTextColor( Color.GREEN );
        else
            mBoardButtons[ location ].setTextColor( Color.RED );
    }

    private void updateWinsCnt(){
        mHumanCntTextView.setText( "Human: " + mCntHumanWins );
        mTiesCntTextView.setText( "Ties: " + mCntTies );
        mAndroidCntTextView.setText( "Android: " + mCntAndroidWins );
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tic_tac_toe);

        mBoardButtons = new Button[TicTacToeGame.BOARD_SIZE];
        mBoardButtons[0] = (Button) findViewById(R.id.bt_one);
        mBoardButtons[1] = (Button) findViewById(R.id.bt_two);
        mBoardButtons[2] = (Button) findViewById(R.id.bt_three);
        mBoardButtons[3] = (Button) findViewById(R.id.bt_four);
        mBoardButtons[4] = (Button) findViewById(R.id.bt_five);
        mBoardButtons[5] = (Button) findViewById(R.id.bt_six);
        mBoardButtons[6] = (Button) findViewById(R.id.bt_seven);
        mBoardButtons[7] = (Button) findViewById(R.id.bt_eight);
        mBoardButtons[8] = (Button) findViewById(R.id.bt_nine);

        mInfoTextView = (TextView) findViewById(R.id.tv_information);
        mHumanCntTextView = (TextView) findViewById(R.id.tv_human_wins);
        mAndroidCntTextView = (TextView) findViewById(R.id.tv_computer_wins);
        mTiesCntTextView = (TextView) findViewById(R.id.tv_ties);
        mGame = new TicTacToeGame();
        mFirstHuman = true;
        mCntHumanWins = mCntTies = mCntAndroidWins = 0;
        startGame();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add( "New Game" );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        startGame();
        return true;
    }

    private class ButtonClickListener implements View.OnClickListener{
        int location;

        public ButtonClickListener( int location ){
            this.location = location;
        }

        @Override
        public void onClick(View view) {
            if( !mBoardButtons[ location ].isEnabled() || mGameOVer ) return;
            setMove( TicTacToeGame.HUMAN_PLAYER, location );

            int winner = mGame.checkForWinner();
            if( winner == 0 ){
                mInfoTextView.setText( R.string.turn_computer );
                int move = mGame.getComputerMove();
                setMove( TicTacToeGame.COMPUTER_PLAYER, move );
                winner = mGame.checkForWinner();
            }
            if( winner == 0 ) mInfoTextView.setText( R.string.turn_human );
            else {
                mGameOVer = true;
                if (winner == 1){
                    ++mCntTies;
                    mInfoTextView.setText( R.string.result_tie );
                }
                else if (winner == 2){
                    ++mCntHumanWins;
                    mInfoTextView.setText( R.string.result_human_wins );
                }
                else{
                    ++mCntAndroidWins;
                    mInfoTextView.setText( R.string.result_computer_wins );
                }
                updateWinsCnt();
                mFirstHuman = !mFirstHuman;
            }
        }
    }

}
