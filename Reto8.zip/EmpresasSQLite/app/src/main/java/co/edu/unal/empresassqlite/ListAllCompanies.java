package co.edu.unal.empresassqlite;

import android.app.ListActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;

import java.util.List;

import DB.CompanyOperations;
import Model.Company;

/**
 * Created by vr on 11/11/17.
 */

public class ListAllCompanies extends ListActivity {
    private CompanyOperations companyOps;
    List<Company> companies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_all_companies);
        companyOps = new CompanyOperations(this);
        companyOps.open();
        companies = companyOps.getAllCompanies();
        companyOps.close();
        ArrayAdapter<Company> adapter = new ArrayAdapter<Company>(this,
                android.R.layout.simple_list_item_1, companies);
        setListAdapter(adapter);
    }
}