package unal.edu.co.osmbonuspack;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.StrictMode;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.LayoutInflaterCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.api.IMapController;
import org.osmdroid.bonuspack.clustering.RadiusMarkerClusterer;
import org.osmdroid.bonuspack.location.NominatimPOIProvider;
import org.osmdroid.bonuspack.location.POI;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity {

    private MapView map;
    private IMapController mapController;
    private GeoPoint curLocation;
    private boolean firstPosition;
    private int maxResults;
    private float ratio;
    private String searchParam;
    private SharedPreferences sharedPrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        map = (MapView) findViewById(R.id.map);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setBuiltInZoomControls(true);
        map.setMultiTouchControls(true);

        mapController = map.getController();
        mapController.setCenter(new GeoPoint(4.63731, -74.08274));
        mapController.setZoom(16);

        firstPosition = true;
        sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        maxResults = sharedPrefs.getInt( "maxResults", 50 );
        ratio = sharedPrefs.getFloat( "ratio", 1.0f );
        searchParam = sharedPrefs.getString( "searchParam", "cinema" );

        LocationManager mLocationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 5, new LocationListener() {
                @Override
                public void onLocationChanged(final Location location) {
                    curLocation = new GeoPoint( location );
                    updatePoints( );
                }
                @Override
                public void onStatusChanged(String s, int i, Bundle bundle) {
                }
                @Override
                public void onProviderEnabled(String s) {
                }
                @Override
                public void onProviderDisabled(String s) {
                }
            });
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        SharedPreferences.Editor ed = sharedPrefs.edit();
        ed.putInt( "maxResults", maxResults );
        ed.putFloat( "ratio", ratio );
        ed.putString( "searchParam", searchParam );
        ed.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate( R.menu.options_menu, menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        LayoutInflater li = LayoutInflater.from( this );
        View getUserInputView = li.inflate( R.layout.dialog_user_input, null );
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder( this );
        alertDialogBuilder.setView( getUserInputView );
        TextView textView = (TextView) getUserInputView.findViewById( R.id.dialog_text_view );
        final EditText editText = (EditText) getUserInputView.findViewById( R.id.dialog_edit_text );
        switch( item.getItemId() ){
            case R.id.menu_max_result:
                textView.setText( "Insert the maximum number of results" );
                editText.setText( String.valueOf( maxResults ) );
                alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        try{
                            maxResults = Integer.parseInt( editText.getText().toString() );
                            updatePoints( );
                        }catch( Exception e ){
                            Toast.makeText( MainActivity.this, "Invalid input", Toast.LENGTH_SHORT ).show();
                        }
                    }
                }).create().show();
                return true;
            case R.id.menu_ratio:
                textView.setText( "Insert the search ratio in km" );
                editText.setText( String.valueOf( ratio ) );
                alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        try{
                            ratio = Float.parseFloat( editText.getText().toString() );
                            updatePoints( );
                        }catch( Exception e ){
                            Toast.makeText( MainActivity.this, "Invalid input", Toast.LENGTH_SHORT ).show();
                        }
                    }
                }).create().show();
                return true;
            case R.id.menu_search:
                textView.setText( "What are you searching for?" );
                editText.setText( searchParam );
                alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        searchParam = editText.getText().toString();
                        updatePoints( );
                    }
                }).create().show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updatePoints( ){
        Marker startMarker = new Marker(map);
        startMarker.setPosition( curLocation );
        startMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        map.getOverlays().clear();
        map.getOverlays().add(startMarker);
        map.invalidate();

        if( firstPosition ) {
            mapController.setCenter(curLocation);
            firstPosition = false;
        }

        getPOI();
    }

    private void getPOI(){
        NominatimPOIProvider poiProvider = new NominatimPOIProvider("http://nominatim.openstreetmap.org/");
        ArrayList<POI> pois = poiProvider.getPOICloseTo(curLocation, searchParam, maxResults, ratio/112.0);
        RadiusMarkerClusterer poiMarkers = new RadiusMarkerClusterer(MainActivity.this);
        map.getOverlays().add(poiMarkers);

        Drawable poiIcon = getResources().getDrawable(R.drawable.marker_poi_default);
        for (POI poi : pois){
            Marker poiMarker = new Marker(map);
            poiMarker.setTitle(poi.mType);
            poiMarker.setSnippet(poi.mDescription);
            poiMarker.setPosition(poi.mLocation);
            poiMarker.setIcon(poiIcon);
            if (poi.mThumbnail != null){
                poiMarker.setImage(new BitmapDrawable(poi.mThumbnail));
            }
            poiMarkers.add(poiMarker);
        }
    }

}
